# Question 1)

binome=("Gaétan", "Aloïs")
print(f"L'étudiant {binome[0]} est en binome avec l'etudiant {binome[1]}")

"""
# Question 2)

binome[1] = "Ethan"
# output : "TypeError: 'tuple' object does not support item assignment"

# Question 3)

del binome[1]
# output : "TypeError: 'tuple' object doesn't support item deletion"

# Question 4)

binome2 = binome + ("Florian", )
#On ne peut pas ajouter d'éléments à un tuplet, on est obligé de le concaténer avec un autre tuplet.
"""