x=float(input("vous cherchez la table de multiplication de quel nombre ?\n"))
for i in range(10):
    print(f"{x} * {i} = {round(x*i, 2)}")