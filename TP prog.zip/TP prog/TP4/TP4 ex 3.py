nMax = 3
v1 = []
v2 = []
scalaire = 0.0
n=int(input("Quelle est la taille de vos vecteurs (entre 1 et 3) ? "))
while not 1<=n<=nMax:
    print("la taille des vecteurs doit être comprise entre 1 et 3.")
    n=int(input("Quelle est la taille de vos vecteurs ? "))

print("Saisie du premier vecteur :")
for i in range(n):
    print(f"v1[{i}] = ", end="")
    v1.append(float(input()))

print("Saisie du second vecteur :")
for i in range(n):
    print(f"v2[{i}] = ", end="")
    v2.append(float(input()))
    scalaire+=v1[i]*v2[i]

print("Le produit scalaire de v1 par v2 vaut", scalaire)