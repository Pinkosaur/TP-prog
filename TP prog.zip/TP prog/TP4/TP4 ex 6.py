liste = [5, 2, 4, 8, 1, 3]
print(liste)

# Question 1)
for i in range(len(liste)-1):
    min=liste[i]
    min_pos=i
    for j in range(i+1, len(liste)):
        if liste[j]<min:
            min=liste[j]
            min_pos=j
    liste[i], liste[min_pos] = liste[min_pos], liste[i]
    print(liste)
    
"""
# Question 2)
print(sorted(liste))

# Question 3)
liste.sort()
print(liste)
"""