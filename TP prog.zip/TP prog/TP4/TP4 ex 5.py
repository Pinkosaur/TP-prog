d=input("Entrez une date au format jjmmaaaa : ")
j=int(d[0:2])
m=int(d[2:4])
a=int(d[4:8])
print(j, m, a)
if m==2:
    if (a%4==0 and a%100!=0 or a%400==0) and j>29:
        print("En février dans une annnée bissextile, le jour ne peut pas dépasser 29.")
    elif j>28:
        print("En février dans une annnée non bissextile, le jour ne peut pas dépasser 28.")
elif (m==4 or m==6 or m==9 or m==11):
    if j>30:
        print("Les jours des mois d'avril, juin, septembre et novembre ne peuvent pas dépasser 30.")
elif j>31:
    print("Les jours ne peuvent pas dépasser 31.")
if m>12:
    print("les mois ne peuvent pas dépasser 12.")

if 0<m<13 and ((m==1 or m == 3 or m== 5 or m == 7 or m == 8 or m == 10 or m ==12) and j<=31 or (m==4 or m==6 or m==9 or m==11) and j<=30 or m==2 and (a%4==0 and a%100!=0 or a%400==0) and j<=29 or m==2 and j<=28):
    print("La date est correcte.")