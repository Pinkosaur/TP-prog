nombreEtudiants = int(input("Donnez le nombre d'etudiants : "))
moyenne = 0.0
notes = []
for i in range(1, nombreEtudiants+1):
    print(f"Note etudiant {i} : ", end="")
    note=float(input())
    while not 0<=note<=20:
        print(f"La note doit être comprise entre 0 et 20\nMerci d'entrer à nouveau la note de l'étudiant {i} : ", end="")
        note=float(input())
    moyenne += note
    notes.append(note)

moyenne/=nombreEtudiants


print("Numéro de l’Etudiant | note | ecart a la moyenne")
for j in range(1, nombreEtudiants+1):
    print(f"{j} | {notes[j-1]} | {round(notes[j-1]-moyenne, 2)}")