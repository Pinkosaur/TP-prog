
a = list(str.lower("engage le jeu que je le gagne"))
b = []
c = []

for i in range(0, len(a)):
    if a[i].isalpha():
        c.append(a[i])

for j in range(1, len(c)+1):
    b.append(c[0-j])

if c == b:
    print("C'est un palindrome")
else:
    print("ce n\'est pas un palindrome")