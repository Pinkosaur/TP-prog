heures = int(input("entrez le nombre d'heures travaillées : "))
salaireHoraire = int(input("Entrez le salaire horaire : "))

if 0<=heures<=160:
    print(f"Votre salaire est de {heures*salaireHoraire} euros.")
elif 160<heures<=200:
    print(f"Votre salaire est de {160*salaireHoraire+(heures-160)*salaireHoraire*1.25} euros.")
elif 200<heures:
    print(f"Votre salaire est de {160 * salaireHoraire + 40 * salaireHoraire * 1.25+(heures-200)*salaireHoraire*1.5} euros.")
else:
    print("Merci d'entrer un nombre d'heures valide")