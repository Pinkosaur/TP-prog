somme = int(input("entrez une somme d'argent : "))

cent = somme//100
cinquante = (somme%100)//50
dix = ((somme%100)%50)//10
deux = (((somme%100)%50)%10)//2
un = 0
if somme%2 == 1:
    un = 1

print(f"{somme} euros, c'est {cent} billet(s) de 100, {cinquante} 50, {dix} de 10, {deux} pièce(s) de 2 et {un} pièce de 1.")