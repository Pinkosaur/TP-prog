prenom1 = input("Entrez le prénom de la 1ère personne : ")
nom1 = input("Entrez le nom de la 1ère personne : ")
prenom2 = input("Entrez le prénom de la 2e personne : ")
nom2 = input("Entrez le nom de la 2e personne : ")

if nom1<nom2:
    print(f"{str.capitalize(prenom1)} {str.upper(nom1)}")
    print(f"{str.capitalize(prenom2)} {str.upper(nom2)}")
elif nom1>nom2:
    print(f"{str.capitalize(prenom2)} {str.upper(nom2)}")
    print(f"{str.capitalize(prenom1)} {str.upper(nom1)}")
elif prenom1<prenom2:
    print(f"{str.capitalize(prenom1)} {str.upper(nom1)}")
    print(f"{str.capitalize(prenom2)} {str.upper(nom2)}")
else:
    print(f"{str.capitalize(prenom2)} {str.upper(nom2)}")
    print(f"{str.capitalize(prenom1)} {str.upper(nom1)}")