import os.path
import datetime

path1=input("entrez le chemin du fichier 1 : ")
path2=input("entrez le chemin du fichier 2 : ")

if os.path.isfile(path1) == False:
    print("Le chemin du fichier 1 est erronné.")
if os.path.isfile(path2) == False:
    print("Le chemin du fichier 2 est erronné.")

if os.path.isfile(path1)== True and os.path.isfile(path2)== True:
    if os.path.getmtime(path1) < os.path.getmtime(path2):
        print(f"Le fichier 2 est le plus récent. Sa date de modification est {datetime.datetime.fromtimestamp(os.path.getmtime(path2))}")
    else:
        print(
            f"Le fichier 1 est le plus récent. Sa date de modification est {datetime.datetime.fromtimestamp(os.path.getmtime(path1))}")