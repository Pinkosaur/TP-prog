T = list(input("entrez une chaine de caractères : "))
voyelles = 0
for i in range(len(T)):
    if (T[i]=="a" or T[i]=="e" or T[i]=="i" or T[i]=="o" or T[i]=="u" or T[i]=="y"):
        voyelles+=1

print(f"La chaine de caractères contient {float(voyelles)/len(T)*100}% de voyelles.")

nbwagon = 0
occurences = []
for j in range(len(T)):
    if T[j]=="w":
        if (T[j+1]=="a" and T[j+2]=="g" and T[j+3]=="o" and T[j+4]=="n"):
            nbwagon+=1
            occurences.append(j)

if nbwagon != 0:
    print(f"la première occurence de la sous-chaine wagon commence au {occurences[0]}e caractère.")
print(f"La sous-chaine 'wagon' apparait {nbwagon} fois dans la chaine de caractères.")
