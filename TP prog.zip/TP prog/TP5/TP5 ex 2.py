S1 = input("entrez votre note et son coefficient : ")
S2 = input("entrez votre note et son coefficient : ")
S3 = input("entrez votre note et son coefficient : ")
S4 = input("entrez votre note et son coefficient : ")
S5 = input("entrez votre note et son coefficient : ")
S11 = S1.split(" ")
S12 = S2.split(" ")
S13 = S3.split(" ")
S14 = S4.split(" ")
S15 = S5.split(" ")

points = (float(S11[0])*float(S11[1])+float(S12[0])*float(S12[1])+float(S13[0])*float(S13[1])+float(S14[0])*float(S14[1])+float(S15[0])*float(S15[1]))
coefficients = (float(S11[1])+float(S12[1])+float(S13[1])+float(S14[1])+float(S15[1]))

moyenne = points/coefficients

print("votre moyenne est", moyenne)
