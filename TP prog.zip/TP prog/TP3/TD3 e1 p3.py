x = 0
a = 0
b = 0
c = 0
for i in range(0, 10):
    x = float(input("Entrez un nombre entre 0 et 20 : "))
    while x<0 or x>20:
        print("ce n'est pas un nombre entre 0 et 20")
        x = float(input("Entrez un nombre entre 0 et 20 :"))
    if x<10:
        a+=1
    elif x>=15:
        c+=1
    else:
        b+=1

print(f"Vous avez entré {a} valeurs strictement inférieures à 10, {b} valeurs entre 10 inclus et 15 exclus, et {c} valeurs supérieures ou égales à 15.")