from random import randint

x = randint(0, 100)
n = 200
c=1

while n!=x:
    if c==1:
        print("Première tentative !")
    else:
        print(f"{c}e tentative :")
    n=int(input("Essayez de deviner le nombre : "))
    c+=1
    if n<x:
        print("Le nombre est plus grand !")
    elif n>x:
        print("le nompbre est plus petit !")

print(f"Félicitations, vous avez trouvé en {c-1} tentatives !")