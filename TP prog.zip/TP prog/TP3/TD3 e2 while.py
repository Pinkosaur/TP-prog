from time import sleep

n = int(input("Entrez un nombre entier positif : "))

while n>0:
    print(n)
    n-=1
    sleep(1)

print("0")