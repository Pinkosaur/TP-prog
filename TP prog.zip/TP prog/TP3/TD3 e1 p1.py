n = int(input("Entrez un entier naturel N : "))
s = 0
for i in range(0, n+1):
    s += i

print("la somme des entiers naturels allant de 0 à N est ", s)
