
boucle=input("Entrez f pour utiliser une boucle for, ou w pour utiliser une boucle while : ")

if boucle==str("f"):
    n=int(input("Entrez un nombre : "))
    f=1
    print("1", end="")
    for i in range(2, n+1):
        f*=i
        print(f"*{i}", end="")
    print(" =", f)
    print(f"La factorielle de {n} est {f}.")
elif boucle==str("w"):
    n=int(input("Entrez un nombre : "))
    x=n
    f=1
    i=1
    print("1", end="")
    while x>0:
        f*=x
        x-=1
        if i>1:
            print(f"*{i}", end="")
        i+=1
    print(" =", f)
    print(f"La factorielle de {n} est {f}.")

