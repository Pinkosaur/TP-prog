debut=int(input("Donnez l'heure de début de la location (un entier) : "))
fin=int(input("Donnez l'heure de fin de la location (un entier) : "))
uneuro=0
deuxeuros=0

while debut>24 or debut<0 or fin>24 or fin<0 or fin==debut or fin<debut:
    if debut>24 or debut<0 or fin>24 or fin<0:
        print("Les heures doivent être comprises entre 0 et 24 !\n\n")
        debut=int(input("Donnez l'heure de début de la location (un entier) : "))
        fin=int(input("Donnez l'heure de fin de la location (un entier) : "))

    if fin==debut:
        print("Attention ! L'heure de fin est identique à l'heure de début.\n\n")
        debut=int(input("Donnez l'heure de début de la location (un entier) :"))
        fin=int(input("Donnez l'heure de fin de la location (un entier) : "))

    if fin<debut:
        print("Attention ! Le début de la location est après la fin...\n\n")
        debut=int(input("Donnez l'heure de début de la location (un entier) : "))
        fin=int(input("Donnez l'heure de fin de la location (un entier) : "))

for i in range(debut, fin):
    if 7<=i<17:
        deuxeuros+=1
    else:
        uneuro+=1

print(f"Vous avez loué votre vélo pendant")
if uneuro>0:
    print(f"{uneuro} heures au tarif horaire de 1.0 euro")
if deuxeuros>0:
    print(f"{deuxeuros} heures au tarif horaire de 2.0 euros")
print(f"Le montant total à payer est de {uneuro+2*deuxeuros} euro(s)")