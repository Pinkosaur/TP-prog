while True:
    if input("Entrez la valeur 100") == str(100):
        break
