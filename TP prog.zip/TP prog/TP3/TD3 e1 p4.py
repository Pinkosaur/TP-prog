x = float(input("Entrez un nombre supérieur à 1 : "))
n = 0
s = 0
while x<=1:
    print("ce n'est pass supérieur à 1")
    x = float(input("Entrez un nombre supérieur à 1 : "))

while s <= x:
    s+=n
    n+=1

print("Le plus grand nombre N possible est ", n-2)