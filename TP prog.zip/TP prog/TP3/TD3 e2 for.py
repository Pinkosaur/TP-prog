from time import sleep

n = int(input("Entrez un nombre entier positif : "))

for i in range(0, n+1):
    print(n)
    n-=1
    sleep(1)