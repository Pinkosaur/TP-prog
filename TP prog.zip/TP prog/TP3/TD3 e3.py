from random import randint

x = randint(0, 100)
n = 200
while n!=x:
    n=int(input("Essayez de deviner le nombre : "))
    if n<x:
        print("Le nombre est plus grand !")
    elif n>x:
        print("le nompbre est plus petit !")

print("Félicitations, vous avez trouvé !")