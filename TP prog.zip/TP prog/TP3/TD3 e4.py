
boucle=input("Entrez f pour utiliser une boucle for, ou w pour utiliser une boucle while : ")

if boucle==str("f"):
    n=int(input("Entrez un nombre : "))
    f=1
    for i in range(1, n+1):
        f*=i
    print(f"La factorielle de {n} est {f}.")
elif boucle==str("w"):
    n=int(input("Entrez un nombre : "))
    x=n
    f=1
    while x>0:
        f*=x
        x-=1
    print(f"La factorielle de {n} est {f}.")

